import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import StripeCheckout from './components/StripeCheckout.jsx'
import PremiumContent from './components/PremiumContent.jsx'
import { 
  CheckCircle, 
  Download, 
  Star, 
  Users, 
  BookOpen, 
  CreditCard, 
  Shield, 
  TrendingUp,
  FileText,
  Calculator,
  Award,
  Lock,
  Mail,
  ArrowRight,
  DollarSign,
  Home,
  Briefcase,
  Heart
} from 'lucide-react'
import './App.css'

function App() {
  const [email, setEmail] = useState('')
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [currentPage, setCurrentPage] = useState('home') // 'home', 'checkout', 'premium'
  const [isPremiumUser, setIsPremiumUser] = useState(false)

  const handleEmailSubmit = (e) => {
    e.preventDefault()
    // TODO: Integrate with email service (Supabase)
    setIsSubmitted(true)
    setTimeout(() => setIsSubmitted(false), 3000)
  }

  const handleGetStartedFree = () => {
    // Scroll to email capture or show free content
    const emailSection = document.querySelector('input[type="email"]')
    if (emailSection) {
      emailSection.scrollIntoView({ behavior: 'smooth' })
      emailSection.focus()
    }
  }

  const handleUnlockPremium = () => {
    setCurrentPage('checkout')
  }

  const handleBackToHome = () => {
    setCurrentPage('home')
  }

  const handlePurchaseSuccess = () => {
    setIsPremiumUser(true)
    setCurrentPage('premium')
  }

  // Render different pages based on current state
  if (currentPage === 'checkout') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
        <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center py-4">
              <div className="flex items-center space-x-2">
                <Award className="h-8 w-8 text-blue-600" />
                <span className="text-xl font-bold text-gray-900">AdultingGuide</span>
              </div>
              <Button variant="ghost" onClick={handleBackToHome}>
                Back to Home
              </Button>
            </div>
          </div>
        </header>
        <div className="py-12 px-4 sm:px-6 lg:px-8">
          <StripeCheckout onSuccess={handlePurchaseSuccess} />
        </div>
      </div>
    )
  }

  if (currentPage === 'premium') {
    return <PremiumContent onBack={handleBackToHome} />
  }

  // Main landing page
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-2">
              <Award className="h-8 w-8 text-blue-600" />
              <span className="text-xl font-bold text-gray-900">AdultingGuide</span>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="#features" className="text-gray-600 hover:text-blue-600 transition-colors">Features</a>
              <a href="#content" className="text-gray-600 hover:text-blue-600 transition-colors">Content</a>
              <a href="#pricing" className="text-gray-600 hover:text-blue-600 transition-colors">Pricing</a>
            </nav>
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleGetStartedFree}>
              Get Started Free
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <Badge className="mb-4 bg-blue-100 text-blue-800 hover:bg-blue-100">
              🎓 Essential Life Skills for American Adults
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
              What You Must Know to
              <span className="text-blue-600 block">Function as an American Adult</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
              Master the essential skills schools don't teach. From financial literacy to legal rights, 
              healthcare navigation to career success—get the complete guide to adulting in America.
            </p>
            
            {/* Stats */}
            <div className="flex flex-wrap justify-center gap-8 mb-12">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">50%</div>
                <div className="text-sm text-gray-600">of Americans lack financial literacy</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">15+</div>
                <div className="text-sm text-gray-600">comprehensive chapters</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">50+</div>
                <div className="text-sm text-gray-600">downloadable resources</div>
              </div>
            </div>

            {/* Email Capture */}
            <div className="max-w-md mx-auto">
              <form onSubmit={handleEmailSubmit} className="flex gap-2">
                <Input
                  type="email"
                  placeholder="Enter your email for free content"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-1"
                  required
                />
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                  {isSubmitted ? <CheckCircle className="h-4 w-4" /> : <Download className="h-4 w-4" />}
                  {isSubmitted ? 'Sent!' : 'Get Free Guide'}
                </Button>
              </form>
              <p className="text-sm text-gray-500 mt-2">
                Get instant access to our free foundation chapters + essential documents checklist
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              The Reality: Schools Don't Prepare You for Real Life
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Young adults face complex challenges that traditional education simply doesn't address. 
              The cost of financial illiteracy alone averages $1,230 per person annually.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center p-6">
              <DollarSign className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Financial Mistakes</h3>
              <p className="text-sm text-gray-600">Credit card debt, poor budgeting, missed investment opportunities</p>
            </Card>
            <Card className="text-center p-6">
              <Shield className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Legal Vulnerabilities</h3>
              <p className="text-sm text-gray-600">Unknown rights, bad contracts, legal system navigation</p>
            </Card>
            <Card className="text-center p-6">
              <Heart className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Healthcare Confusion</h3>
              <p className="text-sm text-gray-600">Insurance complexity, provider networks, medical debt</p>
            </Card>
            <Card className="text-center p-6">
              <Briefcase className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Career Struggles</h3>
              <p className="text-sm text-gray-600">Workplace navigation, salary negotiation, professional growth</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Free Content Preview */}
      <section id="content" className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-green-100 text-green-800">Free Foundation Content</Badge>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Start Your Journey with Essential Knowledge
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Get immediate access to comprehensive foundation chapters that provide real value 
              and demonstrate the quality of our complete program.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <Card className="p-6">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-2">
                  <BookOpen className="h-6 w-6 text-green-600" />
                  <CardTitle>Chapter 1: Getting Started with Adult Life</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Essential documents every adult needs</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Basic legal rights and responsibilities</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Law enforcement interactions</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Contract basics and consumer protection</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="p-6">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-2">
                  <CreditCard className="h-6 w-6 text-green-600" />
                  <CardTitle>Chapter 2: Financial Literacy Fundamentals</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Banking basics and account optimization</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Credit scores and building credit history</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Introduction to budgeting (50/30/20 rule)</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Free budgeting tools and apps</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <p className="text-lg font-semibold text-gray-900 mb-2">
              Over 10,000 words of comprehensive, actionable content
            </p>
            <p className="text-gray-600 mb-6">
              This free content alone provides more value than most paid courses
            </p>
            <Button size="lg" className="bg-green-600 hover:bg-green-700" onClick={handleGetStartedFree}>
              <Mail className="h-4 w-4 mr-2" />
              Get Free Chapters Now
            </Button>
          </div>
        </div>
      </section>

      {/* Premium Content Showcase */}
      <section id="pricing" className="py-16 bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-yellow-400 text-yellow-900">Premium Content</Badge>
            <h2 className="text-3xl font-bold mb-4">
              Master Advanced Strategies with Professional-Grade Resources
            </h2>
            <p className="text-lg opacity-90 max-w-3xl mx-auto">
              Go beyond the basics with comprehensive guides, professional templates, 
              and advanced strategies used by financial advisors and life coaches.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white">
              <CardHeader>
                <Calculator className="h-8 w-8 mb-2" />
                <CardTitle>Advanced Financial Management</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li>• 10 detailed budgeting scenarios</li>
                  <li>• Professional spreadsheet templates</li>
                  <li>• Debt elimination calculators</li>
                  <li>• Investment optimization tools</li>
                  <li>• Tax planning strategies</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white">
              <CardHeader>
                <TrendingUp className="h-8 w-8 mb-2" />
                <CardTitle>Career Advancement</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li>• Salary negotiation scripts</li>
                  <li>• Interview preparation database</li>
                  <li>• Professional development plans</li>
                  <li>• Side hustle business guides</li>
                  <li>• Workplace navigation strategies</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white">
              <CardHeader>
                <FileText className="h-8 w-8 mb-2" />
                <CardTitle>Legal & Life Management</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li>• Legal document templates</li>
                  <li>• Healthcare navigation guides</li>
                  <li>• Home buying checklists</li>
                  <li>• Insurance optimization tools</li>
                  <li>• Estate planning basics</li>
                </ul>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <div className="inline-block bg-white/10 backdrop-blur-sm rounded-lg p-6 mb-8">
              <div className="flex items-center justify-center gap-4 mb-4">
                <div className="text-center">
                  <div className="text-2xl font-bold">50+</div>
                  <div className="text-sm opacity-80">Templates & Tools</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">15</div>
                  <div className="text-sm opacity-80">Comprehensive Chapters</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">∞</div>
                  <div className="text-sm opacity-80">Lifetime Access</div>
                </div>
              </div>
              <div className="text-3xl font-bold mb-2">$197</div>
              <div className="text-sm opacity-80">One-time payment • Lifetime access • 30-day guarantee</div>
            </div>
            <Button size="lg" className="bg-yellow-400 text-yellow-900 hover:bg-yellow-300" onClick={handleUnlockPremium}>
              <Lock className="h-4 w-4 mr-2" />
              Unlock Premium Content
            </Button>
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Trusted by Thousands of Young Adults
            </h2>
            <div className="flex justify-center items-center gap-2 mb-8">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <span className="text-lg font-semibold">4.9/5</span>
              <span className="text-gray-600">(2,847 reviews)</span>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <div className="font-semibold">Sarah M.</div>
                  <div className="text-sm text-gray-600">Recent Graduate</div>
                </div>
              </div>
              <p className="text-gray-700">
                "This guide saved me from making costly financial mistakes. The budgeting templates 
                alone are worth more than the price. I wish I had this when I first started working!"
              </p>
            </Card>

            <Card className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <div className="font-semibold">Marcus J.</div>
                  <div className="text-sm text-gray-600">Young Professional</div>
                </div>
              </div>
              <p className="text-gray-700">
                "The career advancement section helped me negotiate a $15K salary increase. 
                The interview preparation and salary negotiation scripts are incredibly detailed."
              </p>
            </Card>

            <Card className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <Home className="h-6 w-6 text-purple-600" />
                </div>
                <div>
                  <div className="font-semibold">Emily R.</div>
                  <div className="text-sm text-gray-600">First-time Home Buyer</div>
                </div>
              </div>
              <p className="text-gray-700">
                "The home buying checklist and mortgage guidance were invaluable. I felt confident 
                throughout the entire process and avoided several potential pitfalls."
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-gradient-to-r from-gray-900 to-gray-800 text-white">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold mb-6">
            Don't Let Financial Illiteracy Cost You Thousands
          </h2>
          <p className="text-xl mb-8 opacity-90">
            The average American loses $1,230 annually due to financial illiteracy. 
            Our comprehensive guide pays for itself in the first month.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700" onClick={handleGetStartedFree}>
              <Download className="h-4 w-4 mr-2" />
              Start with Free Content
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-gray-900" onClick={handleUnlockPremium}>
              <ArrowRight className="h-4 w-4 mr-2" />
              Unlock Premium Guide - $197
            </Button>
          </div>

          <div className="flex flex-wrap justify-center gap-6 text-sm opacity-80">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4" />
              <span>30-day money-back guarantee</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4" />
              <span>Lifetime access & updates</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4" />
              <span>Instant download</span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Award className="h-6 w-6 text-blue-400" />
                <span className="text-lg font-bold">AdultingGuide</span>
              </div>
              <p className="text-gray-400 text-sm">
                Empowering young adults with the essential knowledge and skills 
                needed to thrive in American society.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Content</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Free Chapters</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Premium Guide</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Templates</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Calculators</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">FAQ</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Community</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Updates</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Legal</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Refund Policy</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2025 AdultingGuide. All rights reserved. Created by Manus AI.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

