import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { 
  Download, 
  FileText, 
  Calculator, 
  BookOpen, 
  Users, 
  Star,
  CheckCircle,
  ArrowLeft,
  ExternalLink,
  Lock
} from 'lucide-react'

const PremiumContent = ({ onBack }) => {
  const [downloadedItems, setDownloadedItems] = useState(new Set())

  const handleDownload = (itemId, filename) => {
    // Simulate download
    setDownloadedItems(prev => new Set([...prev, itemId]))
    
    // In a real implementation, this would trigger actual file download
    alert(`Downloading: ${filename}\n\nIn a real implementation, this would download the actual file.`)
  }

  const chapters = [
    {
      id: 'chapter-1',
      title: 'Getting Started with Adult Life',
      description: 'Essential documents, legal rights, and basic responsibilities',
      type: 'free',
      pages: 25,
      downloads: ['Essential Documents Checklist', 'Legal Rights Reference Card']
    },
    {
      id: 'chapter-2', 
      title: 'Financial Literacy Fundamentals',
      description: 'Banking, credit, and basic budgeting strategies',
      type: 'free',
      pages: 30,
      downloads: ['Basic Budget Template', 'Credit Building Checklist']
    },
    {
      id: 'chapter-3',
      title: 'Advanced Financial Management',
      description: 'Professional budgeting strategies and investment planning',
      type: 'premium',
      pages: 45,
      downloads: ['10 Scenario Budget Templates', 'Debt Elimination Calculator', 'Investment Allocation Tool']
    },
    {
      id: 'chapter-4',
      title: 'Career Development & Advancement',
      description: 'Salary negotiation, interview skills, and professional growth',
      type: 'premium',
      pages: 38,
      downloads: ['Salary Negotiation Scripts', 'Interview Preparation Database', 'Career Development Plan']
    },
    {
      id: 'chapter-5',
      title: 'Healthcare Navigation',
      description: 'Insurance, provider networks, and medical decision-making',
      type: 'premium',
      pages: 32,
      downloads: ['Insurance Comparison Tool', 'Healthcare Cost Calculator', 'Provider Selection Guide']
    },
    {
      id: 'chapter-6',
      title: 'Legal Essentials for Adults',
      description: 'Contracts, tenant rights, and legal document preparation',
      type: 'premium',
      pages: 28,
      downloads: ['Legal Document Templates', 'Tenant Rights Guide', 'Contract Review Checklist']
    },
    {
      id: 'chapter-7',
      title: 'Home Buying & Real Estate',
      description: 'Complete guide to purchasing your first home',
      type: 'premium',
      pages: 42,
      downloads: ['Home Buying Checklist', 'Mortgage Calculator', 'Inspection Guide']
    },
    {
      id: 'chapter-8',
      title: 'Tax Planning & Optimization',
      description: 'Maximize deductions and plan for tax efficiency',
      type: 'premium',
      pages: 35,
      downloads: ['Tax Planning Worksheet', 'Deduction Tracker', 'Tax Calendar']
    }
  ]

  const tools = [
    {
      id: 'budget-analyzer',
      name: 'Advanced Budget Analyzer',
      description: 'Professional-grade spreadsheet with automated calculations and variance analysis',
      type: 'Excel/Google Sheets'
    },
    {
      id: 'debt-calculator',
      name: 'Debt Elimination Calculator',
      description: 'Compare avalanche vs snowball methods with payoff timelines',
      type: 'Excel/Google Sheets'
    },
    {
      id: 'investment-optimizer',
      name: 'Investment Allocation Optimizer',
      description: 'Determine optimal portfolio allocation based on age and risk tolerance',
      type: 'Excel/Google Sheets'
    },
    {
      id: 'salary-negotiator',
      name: 'Salary Negotiation Toolkit',
      description: 'Scripts, research templates, and negotiation strategies',
      type: 'PDF + Templates'
    },
    {
      id: 'emergency-planner',
      name: 'Emergency Fund Planner',
      description: 'Calculate appropriate emergency fund size and funding timeline',
      type: 'Excel/Google Sheets'
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Button 
              variant="ghost" 
              onClick={onBack}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Button>
            <div className="flex items-center space-x-2">
              <Star className="h-6 w-6 text-yellow-500" />
              <span className="text-lg font-bold text-gray-900">Premium Member</span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Welcome Section */}
        <div className="text-center mb-12">
          <Badge className="mb-4 bg-green-100 text-green-800">Premium Access Unlocked</Badge>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Welcome to Your Complete Adulting Guide
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            You now have lifetime access to all premium content, professional templates, 
            and advanced strategies. Start with any chapter or download the tools you need most.
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          <Card className="text-center p-4">
            <BookOpen className="h-8 w-8 text-blue-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-gray-900">15</div>
            <div className="text-sm text-gray-600">Chapters</div>
          </Card>
          <Card className="text-center p-4">
            <FileText className="h-8 w-8 text-green-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-gray-900">200+</div>
            <div className="text-sm text-gray-600">Pages</div>
          </Card>
          <Card className="text-center p-4">
            <Calculator className="h-8 w-8 text-purple-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-gray-900">50+</div>
            <div className="text-sm text-gray-600">Tools & Templates</div>
          </Card>
          <Card className="text-center p-4">
            <Users className="h-8 w-8 text-orange-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-gray-900">∞</div>
            <div className="text-sm text-gray-600">Lifetime Access</div>
          </Card>
        </div>

        {/* Chapter Library */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Complete Chapter Library</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {chapters.map((chapter) => (
              <Card key={chapter.id} className="relative">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge 
                          variant={chapter.type === 'premium' ? 'default' : 'secondary'}
                          className={chapter.type === 'premium' ? 'bg-yellow-400 text-yellow-900' : ''}
                        >
                          {chapter.type === 'premium' ? 'Premium' : 'Free'}
                        </Badge>
                        <span className="text-sm text-gray-500">{chapter.pages} pages</span>
                      </div>
                      <CardTitle className="text-lg">{chapter.title}</CardTitle>
                      <CardDescription>{chapter.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-semibold text-sm mb-2">Included Downloads:</h4>
                      <ul className="space-y-1">
                        {chapter.downloads.map((download, index) => (
                          <li key={index} className="flex items-center gap-2 text-sm">
                            <CheckCircle className="h-3 w-3 text-green-600" />
                            <span>{download}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        className="flex-1"
                        onClick={() => handleDownload(chapter.id, `${chapter.title}.pdf`)}
                      >
                        <Download className="h-3 w-3 mr-1" />
                        {downloadedItems.has(chapter.id) ? 'Downloaded' : 'Download Chapter'}
                      </Button>
                      <Button size="sm" variant="outline">
                        <ExternalLink className="h-3 w-3 mr-1" />
                        Read Online
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Professional Tools */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Professional Tools & Calculators</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tools.map((tool) => (
              <Card key={tool.id}>
                <CardHeader>
                  <div className="flex items-center gap-2 mb-2">
                    <Calculator className="h-5 w-5 text-blue-600" />
                    <Badge variant="outline">{tool.type}</Badge>
                  </div>
                  <CardTitle className="text-lg">{tool.name}</CardTitle>
                  <CardDescription>{tool.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    className="w-full"
                    onClick={() => handleDownload(tool.id, tool.name)}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    {downloadedItems.has(tool.id) ? 'Downloaded' : 'Download Tool'}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Community Access */}
        <section>
          <Card className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
            <CardHeader>
              <div className="flex items-center gap-2 mb-2">
                <Users className="h-6 w-6" />
                <CardTitle className="text-xl">Private Community Forum</CardTitle>
              </div>
              <CardDescription className="text-blue-100">
                Connect with other members, ask questions, and share your progress
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle className="h-4 w-4" />
                    <span>Ask questions and get expert answers</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle className="h-4 w-4" />
                    <span>Share success stories and learn from others</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle className="h-4 w-4" />
                    <span>Get updates on new content and resources</span>
                  </div>
                </div>
                <Button variant="secondary" className="text-blue-700">
                  <Users className="h-4 w-4 mr-2" />
                  Join Community
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  )
}

export default PremiumContent

