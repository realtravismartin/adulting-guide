import { useState } from 'react'
import { loadStripe } from '@stripe/stripe-js'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { 
  CheckCircle, 
  Lock, 
  CreditCard, 
  Shield, 
  Download,
  Star,
  Clock,
  Infinity
} from 'lucide-react'

// This would be your actual Stripe publishable key
// For demo purposes, we'll use a placeholder
const stripePromise = loadStripe('pk_test_placeholder_key')

const StripeCheckout = ({ onSuccess }) => {
  const [isLoading, setIsLoading] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)

  const handlePurchase = async () => {
    setIsLoading(true)
    
    try {
      // In a real implementation, you would:
      // 1. Call your backend to create a Stripe Checkout session
      // 2. Redirect to Stripe Checkout
      // 3. Handle success/cancel redirects
      
      // For demo purposes, we'll simulate the flow
      setTimeout(() => {
        setIsLoading(false)
        setShowSuccess(true)
      }, 2000)
      
    } catch (error) {
      console.error('Payment error:', error)
      setIsLoading(false)
    }
  }

  const handleAccessContent = () => {
    if (onSuccess) {
      onSuccess()
    }
  }

  if (showSuccess) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          <CardTitle className="text-2xl">Payment Successful!</CardTitle>
          <CardDescription>
            Welcome to the complete Adulting Guide. Your premium content is now unlocked.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <h3 className="font-semibold text-green-800 mb-2">What's Included:</h3>
            <ul className="space-y-1 text-sm text-green-700">
              <li>• 15 comprehensive chapters with advanced strategies</li>
              <li>• 50+ professional templates and calculators</li>
              <li>• Lifetime access with free updates</li>
              <li>• Private community forum access</li>
              <li>• 30-day money-back guarantee</li>
            </ul>
          </div>
          <Button className="w-full" size="lg" onClick={handleAccessContent}>
            <Download className="h-4 w-4 mr-2" />
            Access Your Premium Content
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <Badge className="mb-4 bg-yellow-400 text-yellow-900">Premium Content</Badge>
        <h2 className="text-3xl font-bold mb-4">
          Unlock the Complete Adulting Guide
        </h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Get instant access to professional-grade resources, advanced strategies, 
          and comprehensive tools that would typically cost thousands through financial advisors.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 mb-8">
        {/* Pricing Card */}
        <Card className="relative overflow-hidden">
          <div className="absolute top-0 right-0 bg-yellow-400 text-yellow-900 px-3 py-1 text-sm font-semibold">
            Best Value
          </div>
          <CardHeader className="text-center pb-4">
            <CardTitle className="text-2xl">Complete Guide</CardTitle>
            <div className="text-4xl font-bold text-blue-600 mb-2">$197</div>
            <CardDescription>One-time payment • Lifetime access</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                <span className="text-sm">15 comprehensive chapters (200+ pages)</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                <span className="text-sm">50+ professional templates & calculators</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                <span className="text-sm">Advanced budgeting & investment strategies</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                <span className="text-sm">Career advancement & salary negotiation</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                <span className="text-sm">Legal documents & healthcare navigation</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                <span className="text-sm">Private community forum access</span>
              </div>
              <div className="flex items-center gap-3">
                <Infinity className="h-5 w-5 text-blue-600 flex-shrink-0" />
                <span className="text-sm font-semibold">Lifetime access & updates</span>
              </div>
            </div>
            
            <div className="border-t pt-4">
              <Button 
                onClick={handlePurchase}
                disabled={isLoading}
                className="w-full bg-blue-600 hover:bg-blue-700"
                size="lg"
              >
                {isLoading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Processing...
                  </>
                ) : (
                  <>
                    <Lock className="h-4 w-4 mr-2" />
                    Secure Checkout - $197
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Value Comparison */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="h-5 w-5 text-yellow-500" />
              Compare the Value
            </CardTitle>
            <CardDescription>
              See how our guide compares to alternatives
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-sm">Financial advisor consultation</span>
                <span className="font-semibold">$300-500/hour</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-sm">Career coaching session</span>
                <span className="font-semibold">$150-300/hour</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-sm">Legal consultation</span>
                <span className="font-semibold">$200-400/hour</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-sm">Individual courses (each)</span>
                <span className="font-semibold">$50-200</span>
              </div>
              <div className="flex justify-between items-center py-2 bg-green-50 px-3 rounded">
                <span className="text-sm font-semibold text-green-800">Our Complete Guide</span>
                <span className="font-bold text-green-600">$197</span>
              </div>
            </div>
            
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Shield className="h-4 w-4 text-blue-600" />
                <span className="font-semibold text-blue-800">Money-Back Guarantee</span>
              </div>
              <p className="text-sm text-blue-700">
                Try it risk-free for 30 days. If you're not completely satisfied, 
                get a full refund—no questions asked.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Security & Trust */}
      <div className="bg-gray-50 rounded-lg p-6 mb-8">
        <div className="flex flex-wrap justify-center items-center gap-8 text-sm text-gray-600">
          <div className="flex items-center gap-2">
            <CreditCard className="h-4 w-4" />
            <span>Secure SSL encryption</span>
          </div>
          <div className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            <span>Stripe secure payments</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            <span>Instant access</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4" />
            <span>30-day guarantee</span>
          </div>
        </div>
      </div>

      {/* FAQ */}
      <div className="max-w-2xl mx-auto">
        <h3 className="text-xl font-semibold text-center mb-6">Frequently Asked Questions</h3>
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Is this a one-time payment?</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Yes! Pay once and get lifetime access to all current and future content updates. 
                No subscriptions or hidden fees.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">What if I'm not satisfied?</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                We offer a 30-day money-back guarantee. If you're not completely satisfied 
                with the content, contact us for a full refund.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">How do I access the content after purchase?</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Immediately after payment, you'll receive access to your personal dashboard 
                with all premium content, templates, and resources available for download.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default StripeCheckout

